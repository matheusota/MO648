//
//  main.cpp
//  ProblemaMatheusBRKGA
//
//  Created by Ulysses Rocha on 26/10/2018.
//  Copyright © 2018 Ulysses Rocha. All rights reserved.
//

#include <iostream>
#include "CCEAllocation.hpp"

int main(int argc, const char * argv[]) {
    CCEAllocation x;
    x.run();
}
